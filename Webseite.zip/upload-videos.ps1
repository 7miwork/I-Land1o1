<#
.SYNOPSIS
    Laedt den lokalen Ordner .\Videos per FTP zu Hostinger hoch.
.DESCRIPTION
    - Vergleicht Dateigroesse: vorhandene, gleiche Dateien werden uebersprungen.
    - -Force: alles bedingungslos neu hochladen.
    - Nur Upload, es wird NICHTS auf dem Server geloescht.
.EXAMPLE
    .\upload-videos.ps1
    .\upload-videos.ps1 -Force
#>
param(
    [string]$FtpHost = 'ftp://156.67.75.115',
    [string]$User    = 'u670872482.i-land1o1.com',
    [string]$Pass    = '2008Jt$Ml8785',
    [string]$RemoteBase = '/Videos',
    [switch]$Force
)

$ErrorActionPreference = 'Continue'
$localBase = Join-Path $PSScriptRoot 'Videos'
if (-not (Test-Path $localBase)) {
    Write-Host "FEHLER: Lokaler Ordner nicht gefunden: $localBase" -ForegroundColor Red
    exit 1
}

function Get-RemoteSize([string]$url) {
    $h = & curl.exe --connect-timeout 15 -sI $url --user $script:cred 2>$null
    $line = $h | Select-String -Pattern 'content-length' | Select-Object -First 1
    if ($line) {
        $v = 0
        if ([long]::TryParse((($line -split ':')[-1]).Trim(), [ref]$v)) { return $v }
    }
    return -1
}

function Enc-Path([string]$rel) {
    # jede Pfad-Segement-Komponente URL-enkodieren (Leerzeichen etc.)
    ($rel -split '/' | ForEach-Object { [uri]::EscapeDataString($_) }) -join '/'
}

$script:cred = "${User}:${Pass}"
$ok = 0; $skip = 0; $fail = 0

$files = Get-ChildItem $localBase -Recurse -File
Write-Host "=== Video-Upload zu Hostinger ($($files.Count) lokale Dateien) ===`n"

foreach ($f in $files) {
    $rel = $f.FullName.Substring($localBase.Length).TrimStart('\') -replace '\\', '/'
    $url = "$FtpHost$RemoteBase/" + (Enc-Path $rel)

    if (-not $Force) {
        $remoteSize = Get-RemoteSize $url
        if ($remoteSize -eq $f.Length) {
            Write-Host ("SKIP  {0}  ({1:N0} bytes, identisch)" -f $rel, $f.Length) -ForegroundColor DarkGray
            $skip++
            continue
        }
    }

    Write-Host ("UPLOAD {0}  ({1:N0} bytes) ..." -f $rel, $f.Length) -NoNewline
    & curl.exe --connect-timeout 30 --retry 2 -s --ftp-create-dirs `
        --upload-file $f.FullName $url --user $script:cred 2>$null
    $newSize = Get-RemoteSize $url
    if ($LASTEXITCODE -eq 0 -and $newSize -eq $f.Length) {
        Write-Host "  OK" -ForegroundColor Green
        $ok++
    } else {
        Write-Host "  FEHLER (remote-Size=$newSize, lokal=$($f.Length))" -ForegroundColor Red
        $fail++
    }
}

Write-Host "`n=== Fertig: $ok hochgeladen, $skip uebersprungen, $fail Fehler ===" -ForegroundColor $(if ($fail) {'Red'} else {'Green'})
exit $(if ($fail) {1} else {0})
